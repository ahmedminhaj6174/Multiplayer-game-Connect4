// creating variables for each user of the game
var user1 = "Player 1";
var user1Color = 'crimson';

var user2 = "Player 2";
var user2Color = 'blue';



/// query selectors

// selecting each indiviual row
var tbl_row = document.getElementsByTagName('tr');

// selecting each indiviual disc
var tbl_col = document.getElementsByTagName('td');

// selecting each indiviual disc by class name
const discs = document.querySelectorAll('.disc');

// selecting current player's move
var play_move = document.querySelector('.ply_move');

// selecting the restart button
const restart_button = document.querySelector('.restart');



// setting current user to be player 1
var currentPlayer = 1;
// starting game with player 1 making the first click
play_move.textContent = `${user1} color Red!`



/// saving the table coordinates of the disc after every click

for (i = 0; i < tbl_col.length; i ++){
    // adding the event lister click to every disc upon action
    tbl_col[i].addEventListener('click', (e) =>{
        // getting the row and column info of the disc the player clicked
        console.log(`${e.target.parentElement.rowIndex},${e.target.cellIndex}`)
    });
};


/// function created to change color of the disc clicked according to player's color

function player_color_switch(e){

    let column = e.target.cellIndex;
    let row = [];

    // setting the start of the game from bottom row
    for (i = 5; i > -1; i--){
        // going through each disc/column of every row & the setting the color of discs
        if (tbl_row[i].children[column].style.backgroundColor == 'white'){
            row.push(tbl_row[i].children[column]);
            // setting Player 1 's color and winning function startegies
            if (currentPlayer === 1){
                row[0].style.backgroundColor = 'crimson';
                if (hor_match() || ver_match() || diag_match() || anti_diag_match()){
                    play_move.textContent = `${user1} WINS!!`;
                    play_move.style.color = user1Color;
                    return alert(`${user1} WINS!!`);
                }else if (draw_match()){
                    play_move.textContent = 'DRAW!';
                    return alert('DRAW!');
                }else{
                    // turn change to player 2
                    play_move.textContent = `${user2} color Blue!`
                    return currentPlayer = 2;
                }
            }else{
                // setting Player 2 's color and winning function startegies
                row[0].style.backgroundColor = 'blue';
                if (hor_match() || ver_match() || diag_match() || anti_diag_match()){
                    play_move.textContent = `${user2} WINS!!`;
                    play_move.style.color = user2Color;
                    return alert(`${user2} WINS!!`);
                }else if (draw_match()){
                    play_move.textContent = 'DRAW!';
                    return alert('DRAW!');
                }else{
                    // turn change to player 1
                    play_move.textContent = `${user1} color Red!`;
                    return currentPlayer = 1;
                }
                
            }
        }
    }
   
}
    // Set all discs color to white for every new start of the game 
    // And applying change of color function to every disc clicked by the user
Array.prototype.forEach.call(tbl_col, (cell) => {
    cell.addEventListener('click', player_color_switch);
    cell.style.backgroundColor = 'white';
});
/// function created to check matching of colors of 4 discs
function color_match(one, two, three, four){
    return (one === two && one === three && one === four && one !== 'white' && one !== undefined);
}
/// player win check funtion if 4 disc has matching colors horizantally
function hor_match(){
    for (let row = 0; row < tbl_row.length; row++){
        for (let col =0; col < 4; col++){
           if (color_match(tbl_row[row].children[col].style.backgroundColor,tbl_row[row].children[col+1].style.backgroundColor, 
                                tbl_row[row].children[col+2].style.backgroundColor, tbl_row[row].children[col+3].style.backgroundColor)){
               return true;
           }
        }
    }
}
/// player win check funtion if 4 disc has matching colors vertically
function ver_match(){
    for (let col = 0; col < 7; col++){
        for (let row = 0; row < 3; row++){
            if (color_match(tbl_row[row].children[col].style.backgroundColor, tbl_row[row+1].children[col].style.backgroundColor,
                                tbl_row[row+2].children[col].style.backgroundColor,tbl_row[row+3].children[col].style.backgroundColor)){
                return true;
            };
        }   
    }
}
/// player win check funtion if 4 disc has matching colors diagonally
function diag_match(){
    for(let col = 0; col < 4; col++){
        for (let row = 0; row < 3; row++){
            if (color_match(tbl_row[row].children[col].style.backgroundColor, tbl_row[row+1].children[col+1].style.backgroundColor,
                tbl_row[row+2].children[col+2].style.backgroundColor,tbl_row[row+3].children[col+3].style.backgroundColor)){
                    return true;
                }
            }
        }

}
/// player win check funtion if 4 disc has matching colors anti diagonally
function anti_diag_match(){
    for(let col = 0; col < 4; col++){
        for (let row = 5; row > 2; row--){
            if (color_match(tbl_row[row].children[col].style.backgroundColor, tbl_row[row-1].children[col+1].style.backgroundColor,
                tbl_row[row-2].children[col+2].style.backgroundColor,tbl_row[row-3].children[col+3].style.backgroundColor)){
                    return true;
            }
        }
    }
}
/// function implemented to show draw game
function draw_match(){
    let filled_disc = []
    for (i=0; i < tbl_col.length; i++){
        if (tbl_col[i].style.backgroundColor !== 'white'){
            filled_disc.push(tbl_col[i]);
        }
    }
    // checking all the discs are filled with crimson and blue color
    if (filled_disc.length === tbl_col.length){
        return true;
    }
}
/// applying event click in Restart button
restart_button.addEventListener('click', () => {
    discs.forEach(disc => {
        // after every restart making all the disc color white
        disc.style.backgroundColor = 'white';
    });
    play_move.style.color = 'black';
    // setting winner player making the first move
    return (currentPlayer === 1 ? play_move.textContent = `${user1} color Red!` : play_move.textContent = `${user2} color Blue!`);
});



let restart = document.getElementById("restart");

// Briefly make the list red when the mouse moves off the
// div element
restart.addEventListener("mouseleave", function( event ) {
  // highlight the mouseleave target
  event.target.style.color = "red";

  // reset the color after a short delay
  setTimeout(function() {
    event.target.style.color = "";
  }, 3000);
}, false);

// Briefly make orange when the mouse moves off of it
restart.addEventListener("mouseout", function( event ) {
  // highlight the mouseout target
  event.target.style.color = "orange";

  // reset the color after a short delay
  setTimeout(function() {
    event.target.style.color = "";
  }, 1000);
}, false);